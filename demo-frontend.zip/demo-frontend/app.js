// WealthWise Demo - Frontend Only Version
// Realistic Singapore Family Financial Data

// Customer and Personal Details (Based on ER Diagram)
const DEMO_CUSTOMER = {
    customer_id: "WW_2024_001",
    products_bought: ["Financial Planning", "Investment Advisory", "Insurance Review"],
    personal_details: {
        name: "Sarah Chen",
        age: 34,
        marital_status: "Married"
    },
    dependents: [
        {
            name: "Emma Chen",
            relationship: "Daughter",
            age: 8
        },
        {
            name: "Lucas Chen", 
            relationship: "Son",
            age: 5
        }
    ],
    hopes_and_dreams: {
        primary_goal: "Children's Education & Comfortable Retirement",
        retirement: "Age 62 with $1.2M portfolio",
        savings: "Emergency fund + Education fund + Property upgrade"
    }
};

// Financial Details (Aggregator from ER Diagram)
const DEMO_FINANCIAL_DETAILS = {
    // Income streams
    income: [
        {
            income_type: "Primary Salary",
            amount: 6500,
            frequency: "Monthly"
        },
        {
            income_type: "Spouse Salary", 
            amount: 2000,
            frequency: "Monthly"
        }
    ],
    
    // Expense categories
    expenses: [
        {
            expense_type: "Housing (HDB Loan)",
            amount: 1800,
            frequency: "Monthly"
        },
        {
            expense_type: "Food & Groceries",
            amount: 800,
            frequency: "Monthly"
        },
        {
            expense_type: "Transport",
            amount: 400,
            frequency: "Monthly"
        },
        {
            expense_type: "Children (School, Enrichment)",
            amount: 600,
            frequency: "Monthly"
        },
        {
            expense_type: "Insurance Premiums",
            amount: 350,
            frequency: "Monthly"
        },
        {
            expense_type: "Utilities & Phone",
            amount: 250,
            frequency: "Monthly"
        }
    ],
    
    // Assets
    assets: [
        {
            asset_type: "HDB 4-Room Flat",
            current_value: 450000,
            roi: 3.5
        },
        {
            asset_type: "CPF Ordinary Account",
            current_value: 95000,
            roi: 2.5
        },
        {
            asset_type: "CPF Special Account",
            current_value: 45000,
            roi: 4.0
        },
        {
            asset_type: "Bank Savings",
            current_value: 25000,
            roi: 0.5
        },
        {
            asset_type: "Investment Portfolio (STI ETF)",
            current_value: 35000,
            roi: 6.5
        },
        {
            asset_type: "Endowment Policy",
            current_value: 15000,
            roi: 3.0
        }
    ],
    
    // Liabilities
    liabilities: [
        {
            liability_type: "HDB Loan",
            current_value: 320000
        },
        {
            liability_type: "Credit Card",
            current_value: 2500
        }
    ]
};

// Derived Financial Details (Calculated)
const DEMO_DERIVED_DETAILS = {
    total_networth: calculateNetWorth(),
    net_cashflow: calculateNetCashflow()
};

function calculateNetWorth() {
    const totalAssets = DEMO_FINANCIAL_DETAILS.assets.reduce((sum, asset) => sum + asset.current_value, 0);
    const totalLiabilities = DEMO_FINANCIAL_DETAILS.liabilities.reduce((sum, liability) => sum + liability.current_value, 0);
    return totalAssets - totalLiabilities;
}

function calculateNetCashflow() {
    const totalIncome = DEMO_FINANCIAL_DETAILS.income.reduce((sum, income) => sum + income.amount, 0);
    const totalExpenses = DEMO_FINANCIAL_DETAILS.expenses.reduce((sum, expense) => sum + expense.amount, 0);
    return totalIncome - totalExpenses;
}

// Demo conversation messages
const DEMO_MESSAGES = [
    {
        role: "assistant",
        content: "Hi Sarah! I'm your WealthWise financial assistant. I'll help you build a comprehensive financial profile. Let's start with some basic information. What's your name and age?",
        timestamp: "2024-01-15T09:00:00Z"
    },
    {
        role: "user", 
        content: "Hi! I'm Sarah Chen, I'm 34 years old.",
        timestamp: "2024-01-15T09:00:30Z"
    },
    {
        role: "assistant",
        content: "Nice to meet you, Sarah! Are you married or single, and how many people are in your household?",
        timestamp: "2024-01-15T09:00:45Z"
    },
    {
        role: "user",
        content: "I'm married and we have 4 people in our household - me, my husband, and our two children.",
        timestamp: "2024-01-15T09:01:15Z"
    },
    {
        role: "assistant",
        content: "Wonderful! Tell me about your children - their ages and any special considerations for their future?",
        timestamp: "2024-01-15T09:01:30Z"
    },
    {
        role: "user",
        content: "We have Emma who's 8 and Lucas who's 5. We want to make sure we can afford their university education.",
        timestamp: "2024-01-15T09:02:00Z"
    },
    {
        role: "assistant",
        content: "That's great planning! What type of housing do you currently live in?",
        timestamp: "2024-01-15T09:02:15Z"
    },
    {
        role: "user",
        content: "We live in a 4-room HDB flat in Tampines.",
        timestamp: "2024-01-15T09:02:45Z"
    },
    {
        role: "assistant",
        content: "Perfect! Now let's talk about income. What's your household's total monthly gross income?",
        timestamp: "2024-01-15T09:03:00Z"
    },
    {
        role: "user",
        content: "I earn $6,500 per month and my husband earns $2,000 part-time, so total is $8,500.",
        timestamp: "2024-01-15T09:03:30Z"
    },
    {
        role: "assistant",
        content: "Excellent income! What are your approximate monthly living expenses?",
        timestamp: "2024-01-15T09:03:45Z"
    },
    {
        role: "user",
        content: "About $5,200 per month including our HDB loan, food, transport, children's expenses, and insurance.",
        timestamp: "2024-01-15T09:04:15Z"
    },
    {
        role: "assistant",
        content: "Good cash flow! How much do you currently have in total savings and investments?",
        timestamp: "2024-01-15T09:04:30Z"
    },
    {
        role: "user",
        content: "We have about $85,000 in CPF, $25,000 in bank savings, $35,000 in STI ETF, and $15,000 in an endowment policy.",
        timestamp: "2024-01-15T09:05:00Z"
    },
    {
        role: "assistant",
        content: "Impressive savings! Do you have any outstanding loans or debts?",
        timestamp: "2024-01-15T09:05:15Z"
    },
    {
        role: "user",
        content: "Yes, we still owe $320,000 on our HDB loan and have about $2,500 on credit cards.",
        timestamp: "2024-01-15T09:05:45Z"
    },
    {
        role: "assistant",
        content: "What's your risk tolerance for investments - conservative, moderate, or aggressive?",
        timestamp: "2024-01-15T09:06:00Z"
    },
    {
        role: "user",
        content: "We're moderate risk takers. We want growth but not too volatile.",
        timestamp: "2024-01-15T09:06:30Z"
    },
    {
        role: "assistant",
        content: "What's your investment time horizon? When do you plan to retire?",
        timestamp: "2024-01-15T09:06:45Z"
    },
    {
        role: "user",
        content: "We're planning to retire at 62, so about 28 years from now.",
        timestamp: "2024-01-15T09:07:15Z"
    },
    {
        role: "assistant",
        content: "How much can you invest monthly beyond your current savings?",
        timestamp: "2024-01-15T09:07:30Z"
    },
    {
        role: "user",
        content: "We can probably invest an additional $1,500 per month.",
        timestamp: "2024-01-15T09:08:00Z"
    },
    {
        role: "assistant",
        content: "What are your main financial goals?",
        timestamp: "2024-01-15T09:08:15Z"
    },
    {
        role: "user",
        content: "Children's university education, comfortable retirement with $1.2M, and maybe upgrading to a condo eventually.",
        timestamp: "2024-01-15T09:08:45Z"
    },
    {
        role: "assistant",
        content: "Perfect! I've gathered all your information. Your financial profile shows a strong foundation with good income, positive cash flow, and clear goals. Let me analyze your situation and provide recommendations.",
        timestamp: "2024-01-15T09:09:00Z"
    }
];

// Chart variables
let analysisChart = null;
let scenarioChart = null;

// Initialize the demo when page loads
document.addEventListener('DOMContentLoaded', function() {
    console.log('🎭 Initializing WealthWise Demo...');
    initDemo();
    wireTabControls();
});

function initDemo() {
    // Load demo messages
    loadDemoMessages();
    
    // Load all tabs with demo data
    loadDemoAnalysis();
    loadDemoScenarios(); 
    loadDemoPlans();
    
    console.log('✅ Demo initialized successfully');
}

function wireTabControls() {
    const tabButtons = document.querySelectorAll('.tab-button');
    const tabContents = document.querySelectorAll('.tab-content');
    
    tabButtons.forEach(button => {
        button.addEventListener('click', () => {
            const targetTab = button.dataset.tab;
            
            // Remove active class from all buttons and contents
            tabButtons.forEach(btn => btn.classList.remove('active'));
            tabContents.forEach(content => content.classList.remove('active'));
            
            // Add active class to clicked button and corresponding content
            button.classList.add('active');
            document.getElementById(`${targetTab}-content`).classList.add('active');
        });
    });
}

function loadDemoMessages() {
    const messagesContainer = document.getElementById('messages');
    if (!messagesContainer) return;
    
    messagesContainer.innerHTML = '';
    
    DEMO_MESSAGES.forEach(message => {
        const messageEl = document.createElement('div');
        messageEl.className = `message ${message.role}`;
        
        const avatar = message.role === 'user' ? 'S' : 'W';
        const time = new Date(message.timestamp).toLocaleTimeString('en-SG', { 
            hour: '2-digit', 
            minute: '2-digit' 
        });
        
        messageEl.innerHTML = `
            <div class="message-avatar">${avatar}</div>
            <div class="message-content">
                <div class="message-text">${message.content}</div>
                <div class="message-time">${time}</div>
            </div>
        `;
        
        messagesContainer.appendChild(messageEl);
    });
    
    // Scroll to bottom
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

function loadDemoAnalysis() {
    // Generate comprehensive financial projections
    const projectionData = generateComprehensiveProjections();
    
    // Render multiple analysis charts
    renderAnalysisCharts(projectionData);
    
    // Generate insights
    generateAnalysisInsights(projectionData);
}

function generateComprehensiveProjections() {
    const years = [];
    const netWorth = [];
    const income = [];
    const expenses = [];
    const savings = [];
    const insuranceNeeds = [];
    
    const currentNetWorth = DEMO_DERIVED_DETAILS.total_networth;
    const monthlyInvestment = 1500;
    const investmentReturn = 0.065;
    const inflationRate = 0.025;
    
    let currentWorth = currentNetWorth;
    let currentIncome = 8500;
    let currentExpenses = 5200;
    let currentSavings = 25000;
    
    for (let year = 0; year <= 30; year++) {
        years.push(2024 + year);
        
        if (year === 0) {
            netWorth.push(currentWorth);
            income.push(currentIncome * 12);
            expenses.push(currentExpenses * 12);
            savings.push(currentSavings);
            insuranceNeeds.push(currentIncome * 12 * 10); // 10x annual income
        } else {
            // Income grows with inflation + merit increases
            currentIncome *= (1 + inflationRate + 0.015);
            // Expenses grow with inflation
            currentExpenses *= (1 + inflationRate);
            
            // Annual investment and savings
            const annualInvestment = monthlyInvestment * 12;
            const annualSavings = (currentIncome - currentExpenses) * 12;
            currentSavings += annualSavings;
            
            // Investment growth
            const investmentGrowth = currentWorth * investmentReturn;
            currentWorth += annualInvestment + investmentGrowth;
            
            netWorth.push(Math.round(currentWorth));
            income.push(Math.round(currentIncome * 12));
            expenses.push(Math.round(currentExpenses * 12));
            savings.push(Math.round(currentSavings));
            insuranceNeeds.push(Math.round(currentIncome * 12 * 10));
        }
    }
    
    return { years, netWorth, income, expenses, savings, insuranceNeeds };
}

function renderAnalysisCharts(data) {
    // Render Net Worth Chart
    renderChart('netWorthChart', 'Net Worth Projection', data.years, [{
        label: 'Net Worth (SGD)',
        data: data.netWorth,
        borderColor: '#667eea',
        backgroundColor: 'rgba(102, 126, 234, 0.1)',
        fill: true
    }]);
    
    // Render Income vs Expenses Chart
    renderChart('incomeExpenseChart', 'Annual Income vs Expenses', data.years, [
        {
            label: 'Annual Income',
            data: data.income,
            borderColor: '#10b981',
            backgroundColor: 'rgba(16, 185, 129, 0.1)',
            fill: false
        },
        {
            label: 'Annual Expenses',
            data: data.expenses,
            borderColor: '#ef4444',
            backgroundColor: 'rgba(239, 68, 68, 0.1)',
            fill: false
        }
    ]);
    
    // Render Savings Growth Chart
    renderChart('savingsChart', 'Savings Accumulation', data.years, [{
        label: 'Total Savings (SGD)',
        data: data.savings,
        borderColor: '#f59e0b',
        backgroundColor: 'rgba(245, 158, 11, 0.1)',
        fill: true
    }]);
    
    // Render Insurance Needs Chart
    renderChart('insuranceChart', 'Life Insurance Requirements', data.years, [{
        label: 'Required Coverage (SGD)',
        data: data.insuranceNeeds,
        borderColor: '#8b5cf6',
        backgroundColor: 'rgba(139, 92, 246, 0.1)',
        fill: true
    }]);
}

function renderChart(canvasId, title, labels, datasets) {
    const ctx = document.getElementById(canvasId);
    if (!ctx) {
        console.warn(`Canvas ${canvasId} not found`);
        return;
    }
    
    // Destroy existing chart if it exists
    if (window[canvasId + 'Instance']) {
        window[canvasId + 'Instance'].destroy();
    }
    
    window[canvasId + 'Instance'] = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: datasets.map(dataset => ({
                ...dataset,
                borderWidth: 3,
                tension: 0.4,
                pointRadius: 2,
                pointHoverRadius: 6
            }))
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                title: {
                    display: true,
                    text: title,
                    font: {
                        size: 16,
                        weight: 'bold'
                    },
                    color: '#374151'
                },
                legend: {
                    display: datasets.length > 1,
                    position: 'top'
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return '$' + (value / 1000).toFixed(0) + 'K';
                        }
                    },
                    grid: {
                        color: 'rgba(0, 0, 0, 0.1)'
                    }
                },
                x: {
                    grid: {
                        color: 'rgba(0, 0, 0, 0.1)'
                    }
                }
            },
            interaction: {
                intersect: false,
                mode: 'index'
            }
        }
    });
}

function generateAnalysisInsights(data) {
    const insightsContainer = document.getElementById('analysis_insights');
    if (!insightsContainer) return;
    
    const finalNetWorth = data.netWorth[data.netWorth.length - 1];
    const retirementAge = 62;
    const currentAge = 34;
    const yearsToRetirement = retirementAge - currentAge;
    const retirementNetWorth = data.netWorth[yearsToRetirement];
    
    // Calculate life insurance recommendation
    const annualIncome = 8500 * 12;
    const recommendedCover = annualIncome * 10; // 10x annual income
    
    const insights = [
        {
            title: "Retirement Readiness",
            value: `$${(retirementNetWorth / 1000).toFixed(0)}K`,
            description: `Projected net worth at age ${retirementAge}. You're on track to exceed your $1.2M goal!`
        },
        {
            title: "Monthly Surplus",
            value: `$${DEMO_DERIVED_DETAILS.net_cashflow.toLocaleString()}`,
            description: "Strong positive cash flow enables aggressive wealth building"
        },
        {
            title: "Life Insurance Gap",
            value: `$${(recommendedCover / 1000).toFixed(0)}K`,
            description: "Recommended coverage for primary earner (10x annual income)"
        },
        {
            title: "Education Fund Target",
            value: "$200K",
            description: "Estimated cost for both children's university education (local + overseas option)"
        }
    ];
    
    insightsContainer.innerHTML = insights.map(insight => `
        <div class="insight-item">
            <div class="insight-title">${insight.title}</div>
            <div class="insight-value">${insight.value}</div>
            <div class="insight-description">${insight.description}</div>
        </div>
    `).join('');
}

function loadDemoScenarios() {
    const scenarios = generateDemoScenarios();
    renderScenariosUI({ scenarios });
}

function generateDemoScenarios() {
    const baseProjection = generateComprehensiveProjections();
    
    return [
        {
            name: 'Current Path',
            type: 'neutral',
            description: 'Maintaining current financial trajectory with steady income growth and disciplined investing',
            assumptions: [
                '3.5% annual income growth',
                '2.5% inflation rate', 
                '$1,500 monthly investments',
                '6.5% investment returns'
            ],
            data: {
                netWorth: baseProjection.netWorth,
                income: baseProjection.income,
                expenses: baseProjection.expenses,
                savings: baseProjection.savings,
                insuranceNeeds: baseProjection.insuranceNeeds
            },
            impact: {
                income: 0,
                expenses: 0,
                investments: 0,
                netWorth: 0
            }
        },
        {
            name: 'Career Advancement',
            type: 'positive',
            description: 'Promotion and salary increase, enabling higher investment contributions',
            assumptions: [
                '25% immediate salary increase',
                '5% annual growth thereafter',
                '$2,500 monthly investments',
                'Same investment returns'
            ],
            data: generateScenarioComprehensiveProjection(1.25, 1.0, 2500),
            impact: {
                income: +25,
                expenses: 0,
                investments: +67,
                netWorth: +35
            }
        },
        {
            name: 'Job Loss',
            type: 'negative', 
            description: 'Temporary unemployment requiring emergency fund usage and reduced investments',
            assumptions: [
                '6 months unemployment',
                '50% income for 18 months',
                'Emergency fund depletion',
                'Minimal investments for 2 years'
            ],
            data: generateScenarioComprehensiveProjection(0.75, 1.0, 500),
            impact: {
                income: -25,
                expenses: 0,
                investments: -67,
                netWorth: -20
            }
        },
        {
            name: 'Medical Emergency',
            type: 'negative',
            description: 'Major medical expense and increased ongoing healthcare costs',
            assumptions: [
                '$80K immediate medical cost',
                '20% higher monthly expenses',
                'Reduced investment capacity',
                'Insurance covers 70%'
            ],
            data: generateScenarioComprehensiveProjection(1.0, 1.2, 800),
            impact: {
                income: 0,
                expenses: +20,
                investments: -47,
                netWorth: -15
            }
        },
        {
            name: 'Economic Downturn',
            type: 'critical',
            description: 'Recession impact with salary cuts, job insecurity, and market volatility',
            assumptions: [
                '20% salary reduction',
                'Market returns drop to 3%',
                'Conservative investments only',
                'Extended recovery period'
            ],
            data: generateScenarioComprehensiveProjection(0.8, 1.0, 800, 0.03),
            impact: {
                income: -20,
                expenses: 0,
                investments: -47,
                netWorth: -30
            }
        }
    ];
}

function generateScenarioComprehensiveProjection(incomeMultiplier, expenseMultiplier, monthlyInvestment, returnRate = 0.065) {
    const years = [];
    const netWorth = [];
    const income = [];
    const expenses = [];
    const savings = [];
    const insuranceNeeds = [];
    
    const currentNetWorth = DEMO_DERIVED_DETAILS.total_networth;
    const inflationRate = 0.025;
    
    let currentWorth = currentNetWorth;
    let currentIncome = 8500 * incomeMultiplier;
    let currentExpenses = 5200 * expenseMultiplier;
    let currentSavings = 25000;
    
    for (let year = 0; year <= 30; year++) {
        years.push(2024 + year);
        
        if (year === 0) {
            netWorth.push(currentWorth);
            income.push(currentIncome * 12);
            expenses.push(currentExpenses * 12);
            savings.push(currentSavings);
            insuranceNeeds.push(currentIncome * 12 * 10);
        } else {
            currentIncome *= (1 + inflationRate + 0.015);
            currentExpenses *= (1 + inflationRate);
            
            const annualInvestment = monthlyInvestment * 12;
            const annualSavings = (currentIncome - currentExpenses) * 12;
            currentSavings += annualSavings;
            
            const investmentGrowth = currentWorth * returnRate;
            currentWorth += annualInvestment + investmentGrowth;
            
            netWorth.push(Math.round(currentWorth));
            income.push(Math.round(currentIncome * 12));
            expenses.push(Math.round(currentExpenses * 12));
            savings.push(Math.round(currentSavings));
            insuranceNeeds.push(Math.round(currentIncome * 12 * 10));
        }
    }
    
    return { netWorth, income, expenses, savings, insuranceNeeds };
}

function renderScenariosUI(data) {
    const container = document.getElementById('scenarios-content');
    if (!container) return;
    
    const scenarios = data.scenarios;
    const baseline = scenarios[0]; // Current Path as baseline
    
    container.innerHTML = `
        <div class="scenarios-header">
            <h2>Financial Scenarios Analysis</h2>
            <p>Compare different life scenarios and their impact on your financial future</p>
        </div>
        
        <div class="scenario-selector">
            <label for="scenarioSelect">Select Scenario to Analyze:</label>
            <select id="scenarioSelect">
                ${scenarios.map((scenario, index) => `
                    <option value="${index}">${scenario.name}</option>
                `).join('')}
            </select>
        </div>
        
        <div class="scenario-details" id="scenarioDetails">
            <!-- Will be populated by updateScenarioDetails -->
        </div>
        
        <div class="scenarios-comparison">
            <h3>Financial Impact Comparison</h3>
            <div class="scenario-charts-grid">
                <div class="scenario-chart-card">
                    <canvas id="scenarioNetWorthChart"></canvas>
                </div>
                <div class="scenario-chart-card">
                    <canvas id="scenarioIncomeChart"></canvas>
                </div>
                <div class="scenario-chart-card">
                    <canvas id="scenarioExpenseChart"></canvas>
                </div>
                <div class="scenario-chart-card">
                    <canvas id="scenarioSavingsChart"></canvas>
                </div>
            </div>
        </div>
    `;
    
    // Initialize with first scenario
    updateScenarioDetails(scenarios[0]);
    renderScenarioCharts(scenarios[0], baseline);
    
    // Add event listener for scenario selection
    document.getElementById('scenarioSelect').addEventListener('change', (e) => {
        const selectedIndex = parseInt(e.target.value);
        const selectedScenario = scenarios[selectedIndex];
        updateScenarioDetails(selectedScenario);
        renderScenarioCharts(selectedScenario, baseline);
    });
}

function updateScenarioDetails(scenario) {
    const detailsContainer = document.getElementById('scenarioDetails');
    if (!detailsContainer) return;
    
    detailsContainer.innerHTML = `
        <div class="scenario-detail-card ${scenario.type}">
            <div class="scenario-badge ${scenario.type}">${scenario.name}</div>
            <div class="scenario-description">${scenario.description}</div>
            <div class="scenario-assumptions">
                <h4>Key Assumptions</h4>
                <ul>
                    ${scenario.assumptions.map(assumption => `<li>${assumption}</li>`).join('')}
                </ul>
            </div>
        </div>
        <div class="scenario-detail-card neutral">
            <h3>Financial Impact</h3>
            <div class="impact-grid">
                <div class="impact-item">
                    <span class="impact-label">Income Change:</span>
                    <span class="impact-value ${scenario.impact.income >= 0 ? 'positive' : 'negative'}">
                        ${scenario.impact.income >= 0 ? '+' : ''}${scenario.impact.income}%
                    </span>
                </div>
                <div class="impact-item">
                    <span class="impact-label">Expense Change:</span>
                    <span class="impact-value ${scenario.impact.expenses <= 0 ? 'positive' : 'negative'}">
                        ${scenario.impact.expenses >= 0 ? '+' : ''}${scenario.impact.expenses}%
                    </span>
                </div>
                <div class="impact-item">
                    <span class="impact-label">Investment Change:</span>
                    <span class="impact-value ${scenario.impact.investments >= 0 ? 'positive' : 'negative'}">
                        ${scenario.impact.investments >= 0 ? '+' : ''}${scenario.impact.investments}%
                    </span>
                </div>
                <div class="impact-item">
                    <span class="impact-label">Net Worth Impact:</span>
                    <span class="impact-value ${scenario.impact.netWorth >= 0 ? 'positive' : 'negative'}">
                        ${scenario.impact.netWorth >= 0 ? '+' : ''}${scenario.impact.netWorth}%
                    </span>
                </div>
            </div>
        </div>
    `;
}

function renderScenarioCharts(scenario, baseline) {
    const years = Array.from({length: 31}, (_, i) => 2024 + i);
    
    const getScenarioColor = (type) => {
        switch(type) {
            case 'positive': return '#10b981';
            case 'negative': return '#ef4444';
            case 'critical': return '#dc2626';
            default: return '#667eea';
        }
    };
    
    const scenarioColor = getScenarioColor(scenario.type);
    const baselineColor = '#6b7280';
    
    // Net Worth Comparison
    renderScenarioChart('scenarioNetWorthChart', 'Net Worth Comparison', years, [
        {
            label: 'Current Path',
            data: baseline.data.netWorth,
            borderColor: baselineColor,
            backgroundColor: 'rgba(107, 114, 128, 0.1)',
            borderDash: [5, 5]
        },
        {
            label: scenario.name,
            data: scenario.data.netWorth,
            borderColor: scenarioColor,
            backgroundColor: scenarioColor + '20'
        }
    ]);
    
    // Income Comparison
    renderScenarioChart('scenarioIncomeChart', 'Annual Income Comparison', years, [
        {
            label: 'Current Path',
            data: baseline.data.income,
            borderColor: baselineColor,
            backgroundColor: 'rgba(107, 114, 128, 0.1)',
            borderDash: [5, 5]
        },
        {
            label: scenario.name,
            data: scenario.data.income,
            borderColor: scenarioColor,
            backgroundColor: scenarioColor + '20'
        }
    ]);
    
    // Expenses Comparison
    renderScenarioChart('scenarioExpenseChart', 'Annual Expenses Comparison', years, [
        {
            label: 'Current Path',
            data: baseline.data.expenses,
            borderColor: baselineColor,
            backgroundColor: 'rgba(107, 114, 128, 0.1)',
            borderDash: [5, 5]
        },
        {
            label: scenario.name,
            data: scenario.data.expenses,
            borderColor: scenarioColor,
            backgroundColor: scenarioColor + '20'
        }
    ]);
    
    // Savings Comparison
    renderScenarioChart('scenarioSavingsChart', 'Savings Accumulation Comparison', years, [
        {
            label: 'Current Path',
            data: baseline.data.savings,
            borderColor: baselineColor,
            backgroundColor: 'rgba(107, 114, 128, 0.1)',
            borderDash: [5, 5]
        },
        {
            label: scenario.name,
            data: scenario.data.savings,
            borderColor: scenarioColor,
            backgroundColor: scenarioColor + '20'
        }
    ]);
}

function renderScenarioChart(canvasId, title, labels, datasets) {
    const ctx = document.getElementById(canvasId);
    if (!ctx) {
        console.warn(`Canvas ${canvasId} not found`);
        return;
    }
    
    // Destroy existing chart if it exists
    if (window[canvasId + 'Instance']) {
        window[canvasId + 'Instance'].destroy();
    }
    
    window[canvasId + 'Instance'] = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: datasets.map(dataset => ({
                ...dataset,
                borderWidth: dataset.borderDash ? 2 : 3,
                tension: 0.4,
                pointRadius: 1,
                pointHoverRadius: 4,
                fill: false
            }))
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                title: {
                    display: true,
                    text: title,
                    font: {
                        size: 14,
                        weight: 'bold'
                    },
                    color: '#374151'
                },
                legend: {
                    display: true,
                    position: 'top',
                    labels: {
                        usePointStyle: true,
                        padding: 15
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return '$' + (value / 1000).toFixed(0) + 'K';
                        }
                    },
                    grid: {
                        color: 'rgba(0, 0, 0, 0.1)'
                    }
                },
                x: {
                    grid: {
                        color: 'rgba(0, 0, 0, 0.1)'
                    }
                }
            },
            interaction: {
                intersect: false,
                mode: 'index'
            }
        }
    });
}

function loadDemoPlans() {
    const plansContainer = document.getElementById('plans_grid');
    if (!plansContainer) return;
    
    const recommendedPlans = [
        {
            type: 'insurance',
            title: 'Term Life Insurance',
            provider: 'Great Eastern',
            icon: '🛡️',
            features: [
                { label: 'Coverage Amount', value: '$850K' },
                { label: 'Annual Premium', value: '$1,200' },
                { label: 'Term', value: '30 years' },
                { label: 'Renewable', value: 'Yes' }
            ],
            recommendation: {
                title: 'Highly Recommended',
                text: 'Covers 10x your annual income, ensuring family security. Low cost for high coverage.'
            }
        },
        {
            type: 'insurance',
            title: 'Hospitalization Insurance',
            provider: 'AIA',
            icon: '🏥',
            features: [
                { label: 'Coverage', value: 'Private Hospital' },
                { label: 'Annual Limit', value: '$2M' },
                { label: 'Family Premium', value: '$2,400' },
                { label: 'Deductible', value: '$3K' }
            ],
            recommendation: {
                title: 'Essential Coverage',
                text: 'Protects against major medical expenses. Covers whole family including children.'
            }
        },
        {
            type: 'investment',
            title: 'STI ETF (ES3)',
            provider: 'SPDR',
            icon: '📈',
            features: [
                { label: 'Expense Ratio', value: '0.30%' },
                { label: 'Dividend Yield', value: '3.2%' },
                { label: 'Min Investment', value: '$100' },
                { label: '5-Year Return', value: '6.8%' }
            ],
            recommendation: {
                title: 'Core Holding',
                text: 'Low-cost Singapore market exposure. Perfect for long-term wealth building.'
            }
        },
        {
            type: 'investment',
            title: 'Global Equity Fund',
            provider: 'Dimensional',
            icon: '🌍',
            features: [
                { label: 'Geographic', value: 'Global Developed' },
                { label: 'Management Fee', value: '0.45%' },
                { label: 'Min Investment', value: '$1,000' },
                { label: '10-Year Return', value: '8.2%' }
            ],
            recommendation: {
                title: 'Diversification',
                text: 'International exposure reduces Singapore concentration risk. Excellent long-term returns.'
            }
        },
        {
            type: 'investment',
            title: 'Education Savings Plan',
            provider: 'OCBC',
            icon: '🎓',
            features: [
                { label: 'Target Amount', value: '$200K' },
                { label: 'Monthly Contribution', value: '$800' },
                { label: 'Time Horizon', value: '10-13 years' },
                { label: 'Expected Return', value: '5.5%' }
            ],
            recommendation: {
                title: 'Children\'s Future',
                text: 'Dedicated education fund for Emma and Lucas. Tax-efficient structure with guaranteed returns.'
            }
        },
        {
            type: 'insurance',
            title: 'Disability Income Insurance',
            provider: 'Prudential',
            icon: '💼',
            features: [
                { label: 'Monthly Benefit', value: '$4,000' },
                { label: 'Benefit Period', value: 'To age 65' },
                { label: 'Annual Premium', value: '$800' },
                { label: 'Waiting Period', value: '90 days' }
            ],
            recommendation: {
                title: 'Income Protection',
                text: 'Protects your earning ability. Critical for primary breadwinner with dependents.'
            }
        }
    ];
    
    plansContainer.innerHTML = recommendedPlans.map(plan => `
        <div class="plan-card">
            <div class="plan-header">
                <div class="plan-icon ${plan.type}">
                    ${plan.icon}
                </div>
                <div>
                    <div class="plan-title">${plan.title}</div>
                    <div class="plan-provider">${plan.provider}</div>
                </div>
            </div>
            
            <div class="plan-details">
                ${plan.features.map(feature => `
                    <div class="plan-feature">
                        <span class="plan-feature-label">${feature.label}:</span>
                        <span class="plan-feature-value">${feature.value}</span>
                    </div>
                `).join('')}
            </div>
            
            <div class="plan-recommendation">
                <div class="plan-recommendation-title">${plan.recommendation.title}</div>
                <div class="plan-recommendation-text">${plan.recommendation.text}</div>
            </div>
        </div>
    `).join('');
}

// Add CSS for impact grid
const additionalCSS = `
.impact-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 1rem;
    margin-top: 1rem;
}

.impact-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0.75rem;
    background: white;
    border-radius: 8px;
    border: 1px solid #e5e7eb;
}

.impact-label {
    font-size: 0.9rem;
    color: #6b7280;
}

.impact-value {
    font-weight: 600;
    font-size: 1rem;
}

.impact-value.positive {
    color: #10b981;
}

.impact-value.negative {
    color: #ef4444;
}
`;

// Inject additional CSS
const style = document.createElement('style');
style.textContent = additionalCSS;
document.head.appendChild(style);
